﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Television
{
    class query
    {

//        CREATE DATABASE Television
//GO
//USE TELEVISION
//GO

//CREATE TABLE Commands(
//    id INT IDENTITY(1,1) PRIMARY KEY,
//    button VARCHAR(50) NOT NULL,
//    createTime DATETIME DEFAULT(getdate())
//	)

//insert into Commands(button)
//VALUES('1')

//select* from Commands
//delete TOP(1) FROM Commands
//select* from Commands

//SELECT TOP(1) Commands.button, Commands.createTime FROM Commands

   }
}
