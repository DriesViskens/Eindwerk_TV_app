﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Television
{
    public class Command
    {
        public string command { get; set; }
        public DateTime DT { get; set; }
    }
}
